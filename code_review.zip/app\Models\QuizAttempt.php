<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuizAttempt extends Model
{
    use HasFactory;

    protected $fillable = [
        'student_id',   // ← đúng tên cột trong DB
        'quiz_id',
        'score',
        'correct',
        'total',
        'passed',
        'time_spent',
        'answers',
    ];

    protected $casts = [
        'answers'    => 'array',
        'score'      => 'integer',
        'correct'    => 'integer',
        'total'      => 'integer',
        'passed'     => 'boolean',
        'time_spent' => 'integer',
    ];

    // Dùng đúng FK là student_id
    public function user()
    {
        return $this->belongsTo(User::class, 'student_id');
    }

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id');
    }

    public function quiz()
    {
        return $this->belongsTo(Quiz::class);
    }
}